<?php 



add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );



function theme_name_scripts() {
    wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/style.css' );
    
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Great+Vibes&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&family=Mulish:ital,wght@0,200..1000;1,200..1000&family=Oswald:wght@200..700&display=swap', array(), null );
    
    wp_enqueue_script( 'index', get_template_directory_uri() . '/assets/index.js', array(), null, true );
}

add_theme_support( 'post-thumbnails' );   
add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );



function mss_add_custom_css() {
    ?>
    <style>
    .mainview {
        background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/mainview.png');
    }
		.calc{
  			background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/back.png');
		}
		.footer{
				background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/footer.png');
			}
			.calc_pop2 {
				background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/popback.png');
			}
			@media screen and (max-width: 360px) {
				.mainview {
					background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/mainviewsmalll.png');
			}

						}
    </style>
    <?php
}
add_action('wp_head', 'mss_add_custom_css');

function create_equipment_cpt() {
  register_post_type('equipment', [
    'labels' => [
      'name' => 'Техника',
      'singular_name' => 'Техника'
    ],
    'public' => true,
    'has_archive' => true,
    'supports' => ['title', 'thumbnail', 'editor', 'custom-fields'], 
    'menu_icon' => 'dashicons-car',
    'rewrite' => ['slug' => 'equipment']
  ]);

  register_taxonomy('equipment_category', 'equipment', [
    'labels' => ['name' => 'Категории техники'],
    'hierarchical' => true,
    'rewrite' => ['slug' => 'equipment-category']
  ]);
 
  add_post_type_support('equipment', 'custom-fields');
}
add_action('init', 'create_equipment_cpt');


function enqueue_catalog_scripts() {
  wp_enqueue_script('catalog-filter', get_template_directory_uri() . '/assets/index.js', [], '1.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_catalog_scripts');
?>

